#pragma once
#include "Media.h"
class Video :
	public Media
{
public:
	void display() { cout << "Video:\t"; }
};

