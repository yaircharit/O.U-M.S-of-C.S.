#include "MessageUClient.h"

int bytes_to_int(char* b) {
	return (b[0] << 24) | (b[1] << 16) | (b[2] << 8) | (b[4]);
}

MessageUClient::MessageUClient()
{
	WSADATA wsaData;
	ClientRequest* cr;
	ServerPayload* currLoad = nullptr;
	std::string temp, ip;
	int port;

	// Parameters for recieve (most convinient way to recieve and cast data)
	uint32_t msg_id;
	uint8_t msg_type;
	uint32_t msg_size;
	uint32_t procced;
	uint32_t proccessed = 0, recv_size;
	char buffer[1024] = { 0 };
	char header_buffer[7] = { 0 };
	char client_id[16] = { 0 };
	char rsa_key[160] = { 0 };
	char aes_key[128] = { 0 };
	char client_name[255];
	int num_of_users;

	int ret = WSAStartup(MAKEWORD(2, 2), &wsaData);
	std::cout << "Client: Winsock DLL status is " << wsaData.szSystemStatus << std::endl;

	struct sockaddr_in sa = { 0 };
	try {
		// Get Server information from server.info
		std::ifstream server_info("server.info");

		server_info >> temp;
		size_t del_pos = temp.find(':');
		ip = temp.substr(0, del_pos);
		port = atoi(temp.substr(del_pos + 1, temp.length()).c_str());
		server_info.close();

		// Proccess server info
		inet_pton(AF_INET, ip.c_str(), &sa.sin_addr.s_addr);
		sa.sin_family = AF_INET;
		sa.sin_port = htons(port);
	}
	catch (std::exception&) {
		print("invalid server.info file");
		exit(1);
	}

	while (TRUE) {

		int req_num = showMenu(); 

		if (req_num == 0) {
			print("goodbye");
			closesocket(s);
			WSACleanup();
			exit(0);
		}

		try {
			cr = user.getRequest((uint16_t)req_num);  // Get user request
		}
		catch (std::exception& ex) { print(ex.what()); continue; }

		s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
		int RetCode = connect(s, (SOCKADDR*)&sa, sizeof(sa));

		if (RetCode < 0)
		{
			std::cerr << "Client: connect() failed! Error code : " << WSAGetLastError() << std::endl;
			closesocket(s);
			continue;

		}
		else {
			std::cout << "\nClient: connect() is OK, got connected to " << ip << port << \
				"\nClient: Ready for sending and receiving data..." << std::endl << std::endl;
			std::string temp = cr->getMessage();
			send(s, cr->getMessage().c_str(), cr->size(), 0);

			RetCode = shutdown(s, SD_SEND);
			if (RetCode == SOCKET_ERROR) {
				printf("shutdown failed: %d\n", WSAGetLastError());
				closesocket(s);
				WSACleanup();
				exit(1);
			}

			// Recieve message

			int valread = recv(s, header_buffer, 7, 0);
			if (valread == SOCKET_ERROR) {
				printf("recv failed: %d\n", WSAGetLastError());
				closesocket(s);
				continue;
			}
			if (cr)
				delete cr;
			ServerResponse sr = ServerResponse(header_buffer);
			try {
				switch (sr.getCode())
				{
				case 2100:
					valread = recv(s, client_id, sizeof(client_id), 0);
					currLoad = new ServerPayload(2100, client_id);
					break;

				case 2101:
					num_of_users = sr.getPayloadSize() / (sizeof(client_name) + sizeof(client_id));
					for (int i = 0; i < num_of_users; i++) {
						recv(s, client_id, sizeof(client_id), 0);
						recv(s, client_name, sizeof(client_name), 0);
						currLoad = new Payload2101(client_id, client_name);
						sr.setPayload(currLoad);
						user.processResponse(sr);
					}
					break;
				case 2102:
					recv(s, client_id, sizeof(client_id), 0);
					recv(s, rsa_key, sizeof(rsa_key), 0);
					currLoad = new Payload2102(client_id, rsa_key);
					break;

				case 2103:
					recv(s, client_id, sizeof(client_id), 0);
					recv(s, (char*)&msg_id, sizeof(msg_id), 0);
					currLoad = new Payload2103(client_id, 0);
					break;
				case 2104:
					procced = 0;
					if (sr.getPayloadSize() != 0) {
						while (procced < sr.getPayloadSize()) {
							recv(s, buffer, sizeof(client_id) + sizeof(msg_id) + sizeof(msg_type) + sizeof(msg_size), 0);

							currLoad = new Payload2104(buffer);
							procced += currLoad->size();
							switch (((Payload2104*)currLoad)->getMsgType()) {
							case 2:
								// get AES key
								recv(s, aes_key, sizeof(aes_key), 0);
								temp = "";
								temp.append(aes_key, sizeof(aes_key));
								((Payload2104*)currLoad)->setMessage(temp);
								break;
							case 1:
							case 3:
							case 4:
								// get content if theres any
								proccessed = 0;
								temp = "";
								msg_size = ((Payload2104*)currLoad)->getMsgSize();
								while (proccessed < msg_size) {
									recv_size = (msg_size - proccessed > sizeof(buffer)) ? sizeof(buffer) : (msg_size - proccessed);
									recv(s, buffer, recv_size, 0);
									temp.append(buffer, recv_size);
									proccessed += recv_size;
								}
								((Payload2104*)currLoad)->setMessage(temp);
								procced += proccessed;
								break;
							default:
								print("ERROR! unsupported message type with paylaod: " << ((Payload2104*)currLoad)->getMsgType());
								closesocket(s);
								continue;
							}
							sr.setPayload(currLoad);
							user.processResponse(sr);
						}
					}
					else {
						print("No new messages :`(");
					}

					break;

				default: 
					user.processResponse(sr);
					break;
				}
				if (sr.getCode() != 2101 && sr.getCode() != 2104) {
					// ignore special cases
					sr.setPayload(currLoad);
					user.processResponse(sr);
				}
				closesocket(s);
			}
			catch (std::exception& ex) { print(ex.what()); }
		}
	}
	WSACleanup();

}

int MessageUClient::showMenu() {
	print("\nMessageU client at your service.\n\n\
110) Register\n\
120) Request for clients list\n\
130) Request for public key\n\
140) Request for waiting messages\n\
150) Send a text message\n\
151) Send a request for symmetric key\n\
152) Send your symmetric key\n\
153) Send a file\n\
0) Exit client\n\
?");
	int req_num = -1;

	try {
		std::string temp;
		std::getline(std::cin, temp);
		std::stringstream tempss(temp);

		tempss >> req_num;
	}
	catch (std::exception& ex) {
		print(ex.what());
	}
	return req_num;

}