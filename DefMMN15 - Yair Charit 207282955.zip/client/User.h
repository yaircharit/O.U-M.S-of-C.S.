#pragma once
#include <cstdint>
#include <string>
#include "RSAWrapper.h"
#include "AESWrapper.h"
#include "Base64Wrapper.h"
#include <list>
#include "MessageUProtocol.h"
#include <exception>
#include <fstream>
#include <direct.h>
#define GetCurrentDir _getcwd

class User
{
public:
	User(std::string id = "", std::string name = "");
	~User();
	bool operator==(User& other) { return id == other.id; }
	bool operator==(std::string o_id) { return id == o_id; }
	friend class MainUser;
protected:
	std::string id;
	std::string username;
	RSAPublicWrapper* rsa_public;
	AESWrapper* aes;
};

class MainUser: public User {
public:
	MainUser(std::string user_info_file = "my.info");
	~MainUser();

	ClientRequest *getRequest(uint16_t request_code);
	void processResponse(ServerResponse&);
	

private:
	std::string working_dir;
	std::string file_name;
	std::fstream file;
	RSAPrivateWrapper* rsa_private;
	std::list<User*> contacts; 
	User* getUserByName(); 
	User* getUserByName(std::string username);
	User* getUserByID(std::string client_id);
	std::string file_to_string();
	
};
