#include "User.h"

User::User(std::string ID, std::string name) {
	id = ID;
	username = name;
}
User::~User() {
	if (rsa_public)
		delete rsa_public;
	if (aes)
		delete aes;
}

MainUser::~MainUser() {
	if (rsa_private)
		delete rsa_private;
	for (User* user : contacts) {
		delete user;
	}
}

MainUser::MainUser(std::string user_info_file) :User() {
	char buff[FILENAME_MAX]; //create string buffer to hold path
	GetCurrentDir(buff, FILENAME_MAX);
	working_dir.append(buff);
	
	file_name = user_info_file;
	file.open(file_name);
	std::string temp_in;
	if (file) {
		std::getline(file, username);
		std::getline(file, temp_in);
		id = Base16Wrapper::decode(temp_in);
		std::getline(file, temp_in);
		rsa_private = new RSAPrivateWrapper(Base64Wrapper::decode(temp_in.c_str()));
	}
	else {
		rsa_private = new RSAPrivateWrapper();
	}
	rsa_public = new RSAPublicWrapper(rsa_private->getPublicKey());

}

ClientRequest* MainUser::getRequest(uint16_t request_code) {
	std::string temp_in, message,test_msg="1234";
	ClientRequest* res = nullptr;
	User* user;

	if (request_code == 110) {
		if (!file) {
			print("Please enter username");
			std::getline(std::cin, temp_in);
			res = new ClientRequest((uint16_t)1100, id, new Payload1100(temp_in, rsa_public->getPublicKey()));
			username = temp_in;
		}
		else {
			throw std::exception("my.info already exists");
		}
	}
	else {
		if (file) {
			switch (request_code) {
			case 120:
				res = new ClientRequest((uint16_t)1101, id);
				break;

			case 130:
				user = getUserByName();
				if (user) {
					res = new ClientRequest(1102, id, new Payload1102(user->id));	
				}
				else {
					throw std::exception("User was not found, maybe you should update the user database? (request 120)");
				}

				break;

			case 140:
				res = new ClientRequest(1104, id);
				break;

			case 150:
				user = getUserByName();
				if (user) {
					if (user->aes) {
						print("Please enter a message (ENTER to send)");
						std::getline(std::cin, message);
						message = user->aes->encrypt(message.c_str(), message.length());
						res = new ClientRequest(1103, id, new Payload1103(user->id, (uint8_t)3, message));
					}
					else {
						throw std::exception(("ERROR! Please get symmetric key for " + user->username).c_str());
					}
				}
				else {
					throw std::exception("User was not found, maybe you should update the user database? (request 120)");
				}
				break;

			case 151:
				user = getUserByName();
				if (user) {
					if (user->rsa_public) {
						res = new ClientRequest(1103, id, new Payload1103(user->id, (uint8_t)1));
					}
					else {
						throw std::exception(("ERROR! Please get public key for " + user->username).c_str());
					}
				}
				else {
					throw std::exception("User was not found, maybe you should update the user database? (request 120)");
				}
				break;

			case 152:
				user = getUserByName();
				if (user) {
					if (user->rsa_public) {
						if (user->aes == nullptr) {
							user->aes = new AESWrapper();
						}
						std::string aesKey((char*)user->aes->getKey());
						aesKey.resize(16);
						message = user->rsa_public->encrypt(aesKey.c_str(), aesKey.size());
						res = new ClientRequest(1103, id, new Payload1103(user->id, (uint8_t)2, message));
					}
					else {
						throw std::exception(("ERROR! Please get public key for " + user->username).c_str());
					}

				}
				else {
					throw std::exception("User was not found, maybe you should update the user database? (request 120)");
				}
				break;
			case 153:
				user = getUserByName();
				if (user) {
					if (user->aes) {
						try {
							message = file_to_string();
						}
						catch (std::exception& ex) { throw ex; }
						message = user->aes->encrypt(message.c_str(), message.length());
						res = new ClientRequest(1103, id, new Payload1103(user->id, (uint8_t)4, message));
					}
					else {
						//temp_in = ("Please get " + user->username + "'s AES key and try again").c_str();
						throw std::exception(("ERROR! Please get symmetric key for " + user->username).c_str());
					}
				}
				break;
						
			default:
				throw std::exception("ERROR! Wrong input!");
			}
		}
		else {
			throw std::exception("ERROR! only registered users can do that!");
		}
	}
	return res;
}
void MainUser::processResponse(ServerResponse& resp) {
	std::string temp, aes_key,file_name;
	User* user;
	char hex_str[3] = { 0 };

	switch (resp.getCode()) {
	case 2100:
		// Save response info in file.
		if (!file) {
			file.open("my.info", std::ios_base::out);
			id = resp.getPayload()->getClientID();
			file << username << std::endl;
			file << Base16Wrapper::encode(id) << std::endl;
			file << Base64Wrapper::encode(rsa_private->getPrivateKey()) << std::endl;
			print("my.info saved successfuly!");
		}
		else {
			throw std::exception("ERROR! my.info already exists!");
		}
		break;

	case 2101:
		// save and print users list
		print(((Payload2101*)resp.getPayload())->getUsername());
		user = new User(resp.getPayload()->getClientID(), ((Payload2101*)resp.getPayload())->getUsername());
		for (User* con : contacts) {
			if (*con == *user) {
				return;
			}
		}
		contacts.push_back(user);
		break;

	case 2102:
		for (User* con : contacts) {
			if (*con == resp.getPayload()->getClientID()) {
				con->rsa_public = new RSAPublicWrapper(((Payload2102*)resp.getPayload())->getPublicKey());
				print("RSA key for " << con->username << " was saved successfuly");
				return;
			}
		}
		throw std::exception("Error! user doesn't exist");
		break;
	case 2103:
		// Message sent succefuly
		print("Message has been sent succefuly!");
		break;

	case 2104:
		// Print all messages
		user = getUserByID(((Payload2104*)resp.getPayload())->getClientID());
		if (user) {
			switch (((Payload2104*)resp.getPayload())->getMsgType()) {
			case 1:
				temp = "Request for symmetric key";
				break;
			case 2:
				// Recieve and save symetric key
				temp = ((Payload2104*)resp.getPayload())->getMessage();
				try {
					aes_key = rsa_private->decrypt(temp.c_str(),temp.size());
					user->aes = new AESWrapper((const unsigned char*)aes_key.c_str(), aes_key.size());
					temp = "Symmetric key recieved";
				}
				catch (std::exception&) { print("can't decrypt message"); }

				break;
			case 3:
				// Print messages if possible
				if (user->aes) {
					temp = ((Payload2104*)resp.getPayload())->getMessage();
					try {
						temp = user->aes->decrypt(temp.c_str(), temp.length());
					}
					catch (std::exception& ) { print("can't decrypt message"); }
				}
				else {
					//TODO: Save messages to view later (optional)
					throw std::exception(("ERROR! missing symmetric key for " + user->username).c_str());
				}
				break;
			case 4:
				// Save message as a file
				if (user->aes) {
					temp = ((Payload2104*)resp.getPayload())->getMessage();
					try {
						temp = user->aes->decrypt(temp.c_str(), temp.length());
						file_name = working_dir +"\\msg_file.txt";
						try {
							std::ofstream ofile(file_name); // TODO: save in directory %TMP%
							ofile << temp << std::endl;
							ofile.close();
							print("file has been saved successfuly at " +file_name);
						}
						catch (std::exception& ) {
							throw std::exception("Can't save file");
						}
						
					}
					catch (std::exception&) { print("can't decrypt message"); }
					return;
				}
				else {
					temp = "Please get " + user->username + "'s symetric key to save file";
					throw std::exception(temp.c_str());
				}
				break;
			default:
				throw std::exception("Can't proccess meesage type");
			};
			print("From: " << ((user) ? user->username : "<Please update user DB(req 120)>"));
			print("Content:" << std::endl << temp << std::endl << "-----<EOM>-----" << std::endl);
		}
		else {
			throw std::exception("Something went wrong! Please update contacts DB (req 120)");
		}
		break;

	case 9000:
		print("server responded with an error");
		break;
	default:
		print("Recieved Server Response " << resp.getCode() << ". This response is not implemented.");
		break;
	}

}

User* MainUser::getUserByName() {
	std::string username;
	print("Please enter the username you want to reach:");
	std::getline(std::cin, username);
	return getUserByName(username);
}

User* MainUser::getUserByName(std::string username) {
	if (username.size() > 255) {
		throw std::exception("username is too big!");
	}
	username.resize(255, 0);
	for (User* user : contacts) {
		if (user->username == username)
			return user;
	}
	return nullptr;
}

User* MainUser::getUserByID(std::string client_id) {
	if (client_id.size() > 16) {
		throw std::exception("client_id is too big!");
	}
	username.resize(16, 0);
	for (User* user : contacts) {
		if (user->id == client_id)
			return user;
	}
	return nullptr;
}

std::string MainUser::file_to_string() {
	std::string file_name;
	print("To send a file please enter a file path");
	std::getline(std::cin, file_name);
	try {
		std::ifstream t(file_name);
		if (!t.is_open())
			throw std::exception();
		std::stringstream buffer;
		buffer << t.rdbuf();
		return buffer.str();
	}
	catch (std::exception&) {
		throw std::exception("file not found");
	}
}
