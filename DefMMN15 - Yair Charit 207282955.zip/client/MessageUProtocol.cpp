#include "MessageUProtocol.h"



ClientRequest::ClientRequest(uint16_t request_code, std::string client_ID, ClientPayload* request_payload) : CommProtocolBase(request_code) {
	if (code == 1100) {
		client_ID.resize(16, 0);
	}
	if (client_ID.size() != 16) {
		throw std::exception("Illegal client ID length");
	}

	client_id = client_ID;

	payload = request_payload;
	payload_size = payload->size();
}

std::string ClientRequest::getMessage() {
	std::string res = "";
	res += client_id;
	res.append((char*)&version, sizeof(version));
	res.append((char*)&code, sizeof(code));
	res.append((char*)&payload_size, sizeof(payload_size));
	res += payload->getMessage();

	return res;
}


ServerResponse::ServerResponse(char* header_data)
{
	char* pos = header_data;
	version = *(uint8_t*)pos;
	pos += sizeof(version);
	code = *(uint16_t*)pos;
	pos += sizeof(code);
	payload_size = *(uint16_t*)pos;
	pos += sizeof(payload_size);
}

void ServerResponse::setPayload(ServerPayload* Payload) {

	payload = Payload;

}

ServerPayload::ServerPayload(uint16_t payload_code, char* clnt_id) : MessageUBase(payload_code) {
	if (clnt_id) {
		client_id = clnt_id;
		client_id.resize(16, 0);
	}
}

Payload1100::Payload1100(std::string Username, std::string RSA_pub_key) : ClientPayload(1100) {
	if (Username.size() > 255) {
		throw std::exception("illegal username length");
	}
	else if (RSA_pub_key.size() != 160) {
		throw std::exception("Illegal RSA public key length!");
	}
	username = Username;
	username.resize(255, 0);
	rsa_public_key = RSA_pub_key;
}


std::string Payload1100::getMessage() {
	std::string res = "";

	res += username;
	res += rsa_public_key;

	return res;
}


Payload2101::Payload2101(char* client_id, char* Username) : ServerPayload(2101, client_id) {


	username = Username;
	username.resize(255, 0);
}


Payload1102::Payload1102(std::string client_id) :ClientPayload(1102) {
	client_to_reach = client_id;
	client_to_reach.resize(16, 0);
}

std::string Payload1102::getMessage() {
	return client_to_reach;
}

Payload2102::Payload2102(char* client_id, char* rsa_pub_key) : ServerPayload(2102, client_id) {

	public_key.append(rsa_pub_key, 160);
}


Payload1103::Payload1103(std::string dst_client_id, uint8_t message_type, std::string content) :ClientPayload(1103) {
	dest_client_id = dst_client_id;
	dest_client_id.resize(16);
	msg_type = message_type;

	msg_size = content.size();
	msg = content;
}

std::string Payload1103::getMessage() {
	std::string res = "";
	res += dest_client_id;
	res.append((char*)&msg_type, sizeof(msg_type));
	res.append((char*)&msg_size, sizeof(msg_size));
	res += msg;
	return res;
}
Payload2104::Payload2104(char* msg_data) : ServerPayload(2104) {
	char* pos = msg_data;
	client_id = "";
	client_id.append(pos, 16);
	pos += client_id.size();
	msg_id = *(uint32_t*)pos;
	pos += sizeof(msg_id);
	msg_type = *(uint8_t*)pos;
	pos += sizeof(msg_type);
	msg_size = *(uint32_t*)pos;
	pos += sizeof(msg_size);
}


void Payload2104::setMessage(std::string message) {
	msg = message;
	msg_size = msg.size();
}