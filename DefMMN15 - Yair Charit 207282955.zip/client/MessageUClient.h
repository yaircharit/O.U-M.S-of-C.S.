#pragma once

#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib,"cryptlib.lib")

#include <WinSock2.h> 
#include <Windows.h>
#include <ws2tcpip.h>

#include <string> 
#include <iostream> 
#include <fstream>
#include <exception>
#include "User.h"
#include <map>

class MessageUClient
{ 
public:
	MessageUClient();
	~MessageUClient() { }

	int showMenu();
private: 
	
	SOCKET s;
	MainUser user;
};
