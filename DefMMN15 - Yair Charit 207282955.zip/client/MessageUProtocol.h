#pragma once
#include <string>
#include <iostream>

#define print(x) std::cout << x << std::endl;
#define CLIENT_VERSION 2

//TODO: !! REMOVE ALL FRIENDS !!
//TODO: Add documentation


// Base Classes
class MessageUBase {
public:
	MessageUBase(uint16_t msg_code = 0) : code(msg_code) {};
	~MessageUBase() {}
	virtual int size() { return sizeof(code); }
	virtual std::string type() { return "Base"; }

	uint16_t getCode() { return code; }
	friend class ServerResponse;
	friend class ClientRequest;
protected:
	uint16_t code;

};


// Paylaods base classes

class ClientPayload : public MessageUBase {
public:
	ClientPayload(uint16_t payload_code = 0) : MessageUBase(payload_code) { ; }
	~ClientPayload() { ; }
	virtual int size() { return 0; };
	std::string type() override { return "ClientPayload"; }
	virtual std::string getMessage() { return ""; }
	friend class ClientRequest;
};

class ServerPayload : public MessageUBase {
public:
	ServerPayload(uint16_t payload_code = 0, char* clnt_id = NULL);
	~ServerPayload() {}
	virtual int size() { return client_id.size(); }
	std::string type() override { return "ServerPayload"; }
	std::string getClientID() { return client_id; }
	friend class ServerResponse;
protected:
	std::string client_id;
};


// Base MessageU Request & Response protocol classes
class CommProtocolBase : public MessageUBase {


public:
	CommProtocolBase(uint16_t message_code = 0) : MessageUBase(message_code), version(CLIENT_VERSION) {};
	~CommProtocolBase() { if (payload) delete payload; }
	int size() override { return sizeof(code) + sizeof(version) + sizeof(payload_size) + payload_size; }
	virtual MessageUBase* getPayload() = 0;
	virtual uint32_t getPayloadSize() { return payload_size; }
protected:
	uint8_t version;
	uint32_t payload_size;
	MessageUBase* payload;
};

class ClientRequest : public CommProtocolBase {
public:
	ClientRequest(uint16_t request_code, std::string client_ID, ClientPayload* request_payload = new ClientPayload());
	~ClientRequest() { if (payload) delete payload; }
	int size() override { return CommProtocolBase::size() + sizeof(client_id); }
	virtual std::string getMessage();
	std::string type() override { return "ClientRequest"; }
	ClientPayload* getPayload() override { return payload; }
private:
	std::string client_id;
	ClientPayload* payload;
};

class ServerResponse : public CommProtocolBase {
public:
	ServerResponse(char* header_data);
	~ServerResponse() { if (payload) delete payload; }
	std::string type() override { return "ServerResponse"; }
	void setPayload(ServerPayload*);
	ServerPayload* getPayload() override { return payload; }
private:
	ServerPayload* payload;
};


// Request 1100


class Payload1100 :
	public ClientPayload {
public:
	Payload1100(std::string Username, std::string RSA_pub_key);
	~Payload1100() {}
	int size() override { return username.size() + rsa_public_key.size(); }
	std::string getMessage() override;
private:
	std::string username;
	std::string rsa_public_key;
};



class Payload2101 :
	public ServerPayload {
public:
	Payload2101(char* client_id, char* Username);
	~Payload2101() { ; }
	int size() override { return sizeof(client_id) + username.size(); }
	std::string getUsername() { return username; }
private:
	std::string username;
};



class Payload1102 :
	public ClientPayload
{
public:
	Payload1102(std::string client_id);
	~Payload1102() {}
	std::string getMessage() override;
	int size() override { return client_to_reach.size(); }
private:
	std::string client_to_reach;
};

class Payload2102 :
	public ServerPayload
{
public:
	Payload2102(char* client_id, char* rsa_pub_key);
	~Payload2102() {}
	int size() override { return sizeof(client_id) + public_key.size(); }
	std::string getPublicKey() { return public_key; }
private:
	std::string public_key;
};


class Payload1103 :
	public ClientPayload
{
public:
	Payload1103(std::string dst_client_id, uint8_t message_type, std::string content = "");
	~Payload1103() { ; };
	std::string getMessage() override;
	int size() override { return dest_client_id.size() + sizeof(msg_type) + sizeof(msg_size) + msg_size; }
private:
	std::string dest_client_id;
	uint8_t msg_type;
	uint32_t msg_size;
	std::string msg;
};


class Payload2103 :
	public ServerPayload
{
public:
	Payload2103(char* client_id, uint32_t msg_id) : ServerPayload(2103, client_id), msg_id(msg_id) {};
	~Payload2103() {}
	int size() override { return sizeof(client_id) + sizeof(msg_id); }

	uint32_t getMsgID() { return msg_id; }
private:
	uint32_t msg_id;
};

class Payload2104 :
	public ServerPayload
{
public:
	Payload2104(char* msg_data);
	~Payload2104() {}
	int size() override { return sizeof(client_id) + sizeof(msg_id) + sizeof(msg_type) + sizeof(msg_size) + msg_size; }
	void setMessage(std::string message);
	uint32_t getMsgID() { return msg_id; }
	uint8_t getMsgType() { return msg_type; }
	uint32_t getMsgSize() { return msg_size; }
	std::string getMessage() { return msg; }
private:
	uint32_t msg_id;
	uint8_t msg_type;
	uint32_t msg_size;
	std::string msg;
};

