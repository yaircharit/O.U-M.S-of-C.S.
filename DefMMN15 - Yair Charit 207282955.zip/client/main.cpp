// Client side C/C++ program to demonstrate Socket programming

#include "MessageUClient.h"

int main(int argc, char const* argv[])
{
	MessageUClient client = MessageUClient();
	return 0;
}