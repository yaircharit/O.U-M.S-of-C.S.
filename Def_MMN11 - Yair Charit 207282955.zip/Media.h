#pragma once
#include <iostream>
#include <string>

using namespace std;

class Media
{
public:
	virtual void display() = 0;
};

