#pragma once
#include "Media.h"
class Audio :
	public Media
{
public:
	void display() { cout << "Audio:\t"; }
};

